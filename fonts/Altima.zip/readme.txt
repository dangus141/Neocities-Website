﻿Altima
A pixel font by Caveras

Altima is a mixed serif/sans-serif pixel font recreation based on the 
original main text font appearing in the Sony PlayStation video game 
Final Fantasy Tactics, developed by Square and released by Square & 
Sony in 1997.

The font file in this archive was created by Caveras using FontStruct - 
the free, online font-building tool. This font has a homepage where 
this archive and other versions may be found: 
https://fontstruct.com/fontstructors/caveras

Caveras' website: http://caveras.net

Try FontStruct at https://fontstruct.com - It’s easy and it’s fun.

FontStruct is sponsored by FontShop. Visit them at http://fontshop.com. 
FontShop is the original independent font retailer. We’ve been around 
since the dawn of digital type. Whether you need the right font or need 
to create the right font from scratch, let our 23 years of experience 
work for you.

FontStruct is copyright © 2015-2019 Rob Meek.

LEGAL NOTICE:
In using this font you must comply with the licensing terms described 
in the file “license.txt” included with this archive. If you 
redistribute the font file in this archive, it must be accompanied by 
all the other files from this archive, including this one.

Copyright © 2019 Caveras / Cliff Modes.